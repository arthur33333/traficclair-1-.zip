# TraficClair - Deployer sur Vercel (guide simple)

1. Envoyez ce dossier sur un depot GitHub.
2. Creez une base PostgreSQL (Neon, Supabase ou Vercel Postgres) et copiez son URL.
3. Sur Vercel : Add New > Project > choisissez le depot.
4. Ajoutez les variables du fichier `.env.example` (DATABASE_URL, APP_SECRET au minimum).
5. Cliquez sur Deploy.
6. Connectez-vous avec `admin` / `umami`, puis CHANGEZ IMMEDIATEMENT le mot de passe.

## Erreurs frequentes
- "DATABASE_URL is invalid" : l'URL doit commencer par `postgresql://`.
- "Unable to connect to the database" : ajoutez `?sslmode=require` et autorisez les connexions externes.
- Echec d'installation pnpm : verifiez que `vercel.json` est a la racine.

## Licence
Umami est sous licence MIT : vous pouvez le vendre ou l'heberger pour des clients,
a condition de conserver le fichier LICENSE et la mention de copyright d'origine.

TraficClair est base sur le logiciel libre Umami (c) Umami Software, Inc., licence MIT.
