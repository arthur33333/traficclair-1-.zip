import { Column, Heading, Row, SearchField, Text } from '@umami/react-zen';
import { useMemo, useState } from 'react';
import { List, type RowComponentProps } from 'react-window';
import { SessionModal } from '@/app/(main)/websites/[websiteId]/sessions/SessionModal';
import { Avatar } from '@/components/common/Avatar';
import { Empty } from '@/components/common/Empty';
import { IconLabel } from '@/components/common/IconLabel';
import Link from '@/components/common/Link';
import {
  useCountryNames,
  useLocale,
  useMessages,
  useMobile,
  useNavigation,
  useTimezone,
  useWebsite,
} from '@/components/hooks';
import { useFormat } from '@/components/hooks/useFormat';
import { Eye, User } from '@/components/icons';
import { FilterButtons } from '@/components/input/FilterButtons';
import { Lightning } from '@/components/svg';
import { BROWSERS, OS_NAMES } from '@/lib/constants';

const TYPE_ALL = 'all';
const TYPE_PAGEVIEW = 'pageview';
const TYPE_SESSION = 'session';
const TYPE_EVENT = 'event';
const MAX_LIST_HEIGHT = 500;
const ROW_HEIGHT = 50;

const icons = {
  [TYPE_PAGEVIEW]: <Eye />,
  [TYPE_SESSION]: <User />,
  [TYPE_EVENT]: <Lightning />,
};

export function RealtimeLog({ data }: { data: any }) {
  const website = useWebsite();
  const [search, setSearch] = useState('');
  const { t, labels, messages } = useMessages();
  const { formatValue } = useFormat();
  const { locale } = useLocale();
  const { formatTimezoneDate } = useTimezone();
  const { countryNames } = useCountryNames(locale);
  const [filter, setFilter] = useState(TYPE_ALL);
  const { updateParams } = useNavigation();
  const { isPhone } = useMobile();

  const buttons = [
    {
      label: t(labels.all),
      id: TYPE_ALL,
    },
    {
      label: t(labels.views),
      id: TYPE_PAGEVIEW,
    },
    {
      label: t(labels.visitors),
      id: TYPE_SESSION,
    },
    {
      label: t(labels.events),
      id: TYPE_EVENT,
    },
  ];

  const getTime = ({ createdAt, firstAt }) => formatTimezoneDate(firstAt || createdAt, 'pp');

  const getIcon = ({ __type }) => icons[__type];

  const getDetail = (log: {
    __type: string;
    eventName: string;
    urlPath: string;
    browser: string;
    os: string;
    country: string;
    device: string;
    hostname: string;
  }) => {
    const { __type, eventName, urlPath, browser, os, country, device, hostname } = log;

    if (__type === TYPE_EVENT) {
      return t.rich(messages.eventLog, {
        event: eventName || t(labels.unknown),
        url: urlPath,
        b: chunks => <b>{chunks}</b>,
        a: chunks => (
          <a
            href={`//${hostname}${urlPath}`}
            style={{ fontWeight: 'bold' }}
            target="_blank"
            rel="noreferrer noopener"
          >
            {chunks}
          </a>
        ),
      });
    }

    if (__type === TYPE_PAGEVIEW) {
      return (
        <a
          href={`//${hostname}${urlPath}`}
          style={{ fontWeight: 'bold' }}
          target="_blank"
          rel="noreferrer noopener"
        >
          {urlPath}
        </a>
      );
    }

    if (__type === TYPE_SESSION) {
      return t.rich(messages.visitorLog, {
        country: countryNames[country] || t(labels.unknown),
        browser: BROWSERS[browser],
        os: OS_NAMES[os] || os,
        device: t(labels[device] || labels.unknown),
        b: chunks => <b>{chunks}</b>,
      });
    }
  };

  const TableRow = ({ index, style, logs }: RowComponentProps<{ logs: any[] }>) => {
    const row = logs[index];
    return (
      <Row alignItems="center" style={{ ...style, minWidth: 0 }} gap>
        <Row minWidth="30px">
          <Link href={updateParams({ session: row.sessionId })}>
            <Avatar seed={row.sessionId} size={32} />
          </Link>
        </Row>
        <Row minWidth="100px">
          <Text wrap="nowrap">{getTime(row)}</Text>
        </Row>
        <IconLabel icon={getIcon(row)} style={{ minWidth: 0, flex: 1 }}>
          <Text truncate>{getDetail(row)}</Text>
        </IconLabel>
      </Row>
    );
  };

  const logs = useMemo(() => {
    if (!data) {
      return [];
    }

    let logs = data.events;

    if (search) {
      logs = logs.filter(({ eventName, urlPath, browser, os, country, device }) => {
        return [
          eventName,
          urlPath,
          os,
          formatValue(browser, 'browser'),
          formatValue(country, 'country'),
          formatValue(device, 'device'),
        ]
          .filter(n => n)
          .map(n => n.toLowerCase())
          .join('')
          .includes(search.toLowerCase());
      });
    }

    if (filter !== TYPE_ALL) {
      return logs.filter(({ __type }) => __type === filter);
    }

    return logs;
  }, [data, filter, formatValue, search]);

  const listHeight = Math.min(logs.length * ROW_HEIGHT, MAX_LIST_HEIGHT);

  return (
    <Column gap="3">
      <Heading size="base">{t(labels.activity)}</Heading>
      {isPhone ? (
        <>
          <Row marginBottom="1">
            <SearchField
              value={search}
              onSearch={setSearch}
              placeholder={t(labels.search)}
              className="w-full max-w-md"
            />
          </Row>
          <Row>
            <FilterButtons items={buttons} value={filter} onChange={setFilter} />
          </Row>
        </>
      ) : (
        <Row alignItems="center" justifyContent="space-between" gap="4">
          <SearchField
            value={search}
            onSearch={setSearch}
            placeholder={t(labels.search)}
            className="w-full max-w-md"
          />
          <FilterButtons items={buttons} value={filter} onChange={setFilter} />
        </Row>
      )}

      <Column gap="3">
        {logs?.length === 0 && <Empty />}
        {logs.length > 0 && (
          <List
            rowComponent={TableRow}
            rowCount={logs.length}
            rowHeight={ROW_HEIGHT}
            rowProps={{ logs }}
            defaultHeight={listHeight}
            style={{ width: '100%', height: listHeight }}
          />
        )}
      </Column>
      <SessionModal websiteId={website.id} />
    </Column>
  );
}
