import { Dialog, ListItem, ListSeparator, Modal, Select, type SelectProps } from '@umami/react-zen';
import { Fragment, type Key, useState } from 'react';
import { ControlledDialog } from '@/components/common/ControlledDialog';
import { DateDisplay } from '@/components/common/DateDisplay';
import { useMessages, useMobile } from '@/components/hooks';
import { DatePickerForm } from '@/components/metrics/DatePickerForm';
import { getMaxSelectableDate, parseDateRange } from '@/lib/date';

export interface DateFilterProps extends Omit<SelectProps, 'value' | 'onChange'> {
  value?: string;
  onChange?: (value: string) => void;
  showAllTime?: boolean;
  renderDate?: boolean;
  placement?: any;
}

export function DateFilter({
  value,
  onChange,
  showAllTime,
  renderDate,
  placement = 'bottom',
  ...props
}: DateFilterProps) {
  const { t, labels } = useMessages();
  const [showPicker, setShowPicker] = useState(false);
  const { startDate, endDate } = parseDateRange(value) || {};
  const { isMobile } = useMobile();

  const options = [
    { label: t(labels.today), value: '0day' },
    {
      label: t(labels.lastHours, { x: '24' }),
      value: '24hour',
    },
    {
      label: t(labels.thisWeek),
      value: '0week',
      divider: true,
    },
    {
      label: t(labels.lastDays, { x: '7' }),
      value: '7day',
    },
    {
      label: t(labels.thisMonth),
      value: '0month',
      divider: true,
    },
    {
      label: t(labels.lastDays, { x: '30' }),
      value: '30day',
    },
    {
      label: t(labels.lastDays, { x: '90' }),
      value: '90day',
    },
    { label: t(labels.thisYear), value: '0year' },
    {
      label: t(labels.lastMonths, { x: '6' }),
      value: '6month',
      divider: true,
    },
    {
      label: t(labels.lastMonths, { x: '12' }),
      value: '12month',
    },
    showAllTime && {
      label: t(labels.allTime),
      value: 'all',
      divider: true,
    },
    {
      label: t(labels.customRange),
      value: 'custom',
      divider: true,
    },
  ]
    .filter(n => n)
    .map((a, id) => ({ ...a, id }));

  const handleChange = (value: Key) => {
    if (value === 'custom') {
      setShowPicker(true);
      return;
    }
    onChange(value.toString());
  };

  const handlePickerChange = (value: string) => {
    setShowPicker(false);
    onChange(value.toString());
  };

  const renderValue = ({ defaultChildren }) => {
    return value?.startsWith('range') || renderDate ? (
      <DateDisplay startDate={startDate} endDate={endDate} />
    ) : (
      defaultChildren
    );
  };

  const selectedValue = value.endsWith(':all') ? 'all' : value;

  const [side, align] = String(placement).split(' ');

  return (
    <>
      <Select
        {...props}
        value={selectedValue}
        placeholder={t(labels.selectDate)}
        onChange={handleChange}
        renderValue={renderValue}
        popoverProps={{
          side: side as any,
          align: (align === 'top' ? 'start' : align === 'bottom' ? 'end' : align) as any,
          style: isMobile
            ? {
                // Base UI's positioned wrapper contains React Zen's fullscreen popup.
                position: 'fixed',
                top: 0,
                right: 0,
                bottom: 0,
                left: 0,
                width: '100vw',
                height: '100dvh',
                transform: 'none',
              }
            : { minWidth: 200 },
        }}
        isFullscreen={isMobile}
      >
        {options.map(({ label, value, divider }: any) => {
          return (
            <Fragment key={label}>
              {divider && <ListSeparator />}
              <ListItem id={value}>{label}</ListItem>
            </Fragment>
          );
        })}
      </Select>
      {showPicker && (
        <ControlledDialog>
          <Modal isOpen={true}>
            <Dialog>
              <DatePickerForm
                startDate={startDate}
                endDate={endDate}
                minDate={new Date(2000, 0, 1)}
                maxDate={getMaxSelectableDate()}
                onChange={handlePickerChange}
                onClose={() => setShowPicker(false)}
              />
            </Dialog>
          </Modal>
        </ControlledDialog>
      )}
    </>
  );
}
