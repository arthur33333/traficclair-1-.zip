import { Button, Column } from '@umami/react-zen';
import type { ErrorInfo, ReactNode } from 'react';
import { ErrorBoundary as Boundary } from 'react-error-boundary';
import { useMessages } from '@/components/hooks';

const logError = (error: unknown, info: ErrorInfo) => {
  // eslint-disable-next-line no-console
  console.error(error instanceof Error ? error : new Error(String(error)), info.componentStack);
};

export function ErrorBoundary({ children }: { children: ReactNode }) {
  const { t, messages } = useMessages();

  const fallbackRender = ({ error, resetErrorBoundary }) => {
    return (
      <Column
        role="alert"
        gap
        width="100%"
        height="100%"
        position="absolute"
        justifyContent="center"
        alignItems="center"
      >
        <h1>{t(messages.error)}</h1>
        <h3>{error.message}</h3>
        <pre>{error.stack}</pre>
        <Button onClick={resetErrorBoundary}>OK</Button>
      </Column>
    );
  };

  return (
    <Boundary fallbackRender={fallbackRender} onError={logError}>
      {children}
    </Boundary>
  );
}
